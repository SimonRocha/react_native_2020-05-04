# [2.5.2](https://github.com/GeekyAnts/NativeBase-KitchenSink/releases/tag/v2.5.2)



