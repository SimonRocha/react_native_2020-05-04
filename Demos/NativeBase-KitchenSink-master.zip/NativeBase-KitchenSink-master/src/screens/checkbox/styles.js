export default {
  container: {
    backgroundColor: "#FFF"
  }
};
