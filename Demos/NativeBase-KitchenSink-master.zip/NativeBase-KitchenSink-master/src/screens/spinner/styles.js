const React = require("react-native");

const { StyleSheet } = React;

export default {
  container: {
    backgroundColor: "#FBFAFA"
  }
};
